import request from './request'

/**
 * 获取授权信息
 * @param data {appKey,appSecret}
 * @returns 
 */
export function getAuth(data) {
    return request({
      url: '/getAuth',
      method: 'post',
      data
    })
}


